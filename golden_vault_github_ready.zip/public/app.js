
async function api(path, opts={}){
  const res = await fetch(path, Object.assign({credentials:'same-origin', headers:{'Content-Type':'application/json'}}, opts));
  return res.json();
}
function $(id){return document.getElementById(id);}
$('#show-register')?.addEventListener('click', e=>{e.preventDefault(); $('#login').classList.add('hidden'); $('#register').classList.remove('hidden');});
$('#show-login')?.addEventListener('click', e=>{e.preventDefault(); $('#register').classList.add('hidden'); $('#login').classList.remove('hidden');});

$('#btn-register')?.addEventListener('click', async ()=>{
  const name = $('#reg-name').value, email = $('#reg-email').value, password = $('#reg-password').value, security = $('#reg-security').value;
  const r = await api('/api/register',{method:'POST', body: JSON.stringify({name,email,password,security_answer:security})});
  if(r.ok){ init(); } else { $('#auth-msg').textContent = r.error || 'Error'; }
});

$('#btn-login')?.addEventListener('click', async ()=>{
  const email = $('#login-email').value, password = $('#login-password').value;
  const r = await api('/api/login',{method:'POST', body: JSON.stringify({email,password})});
  if(r.ok){ init(); } else { $('#auth-msg').textContent = r.error || 'Invalid login'; }
});

$('#btn-logout')?.addEventListener('click', async ()=>{ await api('/api/logout',{method:'POST'}); location.reload(); });

async function init(){
  const me = await api('/api/me');
  if(!me.user){ $('#auth-pane').classList.remove('hidden'); $('#dashboard').classList.add('hidden'); $('#admin-pane').classList.add('hidden'); return; }
  $('#auth-pane').classList.add('hidden'); $('#dashboard').classList.remove('hidden'); $('#admin-pane').classList.add('hidden');
  $('#welcome').textContent = 'Welcome, ' + (me.user.name || me.user.email); $('#balance').textContent = 'Balance: ₦' + (me.user.balance||0).toFixed(2);
  loadMessages(); loadTransactions();
}

$('#btn-deposit')?.addEventListener('click', async ()=>{
  const amount = Number($('#deposit-amount').value), ref = $('#deposit-ref').value;
  const r = await api('/api/deposit',{method:'POST', body: JSON.stringify({amount,ref})});
  if(r.ok){ $('#deposit-msg').textContent = 'Deposit recorded'; init(); } else $('#deposit-msg').textContent = r.error;
});

let activeReq = null;
$('#wd-start')?.addEventListener('click', async ()=>{
  const amount = Number($('#wd-amount').value), vat = $('#wd-vat').value;
  const r = await api('/api/withdraw/start',{method:'POST', body: JSON.stringify({amount,vat_code:vat})});
  if(r.ok){ activeReq = r.id; $('#demo-otp').textContent = r.otp; $('#wd1').classList.add('hidden'); $('#wd2').classList.remove('hidden'); } else $('#wd-msg1').textContent = r.error;
});
$('#wd-verify')?.addEventListener('click', async ()=>{
  const otp = $('#wd-otp').value; const r = await api('/api/withdraw/verify-otp',{method:'POST', body: JSON.stringify({id: activeReq, otp})});
  if(r.ok){ $('#wd2').classList.add('hidden'); $('#wd3').classList.remove('hidden'); } else $('#wd-msg2').textContent = r.error;
});
$('#wd-sec-btn')?.addEventListener('click', async ()=>{
  const ans = $('#wd-sec').value; const r = await api('/api/withdraw/security',{method:'POST', body: JSON.stringify({id: activeReq, answer: ans})});
  if(r.ok){ $('#wd3').classList.add('hidden'); $('#wd4').classList.remove('hidden'); $('#wd-id').textContent = activeReq; } else $('#wd-msg3').textContent = r.error;
});
$('#wd-check')?.addEventListener('click', async ()=>{
  const r = await api('/api/withdraw/status/' + activeReq);
  if(r.request && r.request.admin_approved){ $('#wd4').classList.add('hidden'); $('#wd5').classList.remove('hidden'); $('#wd-final').textContent = 'Withdrawal completed: ₦' + r.request.amount; init(); }
  else $('#wd-msg4').textContent = 'Still pending admin approval';
});
$('#wd-done')?.addEventListener('click', ()=>{ activeReq = null; $('#wd5').classList.add('hidden'); $('#wd1').classList.remove('hidden'); });

async function loadTransactions(){ const r = await api('/api/transactions'); const el = $('#tx-list'); el.innerHTML=''; (r.rows||[]).forEach(t=> el.innerHTML += `<div class="tx">${t.type.toUpperCase()} • ${t.ref||''} • ₦${t.amount} • ${new Date(t.ts||0).toLocaleString()}</div>`); }

async function loadMessages(){ const r = await api('/api/messages'); const el = $('#messages'); el.innerHTML=''; (r.rows||[]).forEach(m=> el.innerHTML += `<div class="msg-card"><strong>${m.from_user||'System'}</strong>: ${m.body} <small>${new Date(m.ts||0).toLocaleString()}</small></div>`); }

// Admin UI open
$('#open-admin')?.addEventListener('click', (e)=>{ e.preventDefault(); $('#admin-pane').classList.remove('hidden'); $('#auth-pane').classList.add('hidden'); $('#dashboard').classList.add('hidden'); });
$('#admin-login-btn')?.addEventListener('click', async ()=>{
  const email = $('#admin-email').value, password = $('#admin-password').value;
  const r = await api('/api/login',{method:'POST', body: JSON.stringify({email,password})});
  if(r.ok && r.role==='admin'){ $('#admin-login-area').classList.add('hidden'); $('#admin-area').classList.remove('hidden'); loadAdmin(); } else alert('Admin login failed');
});
$('#admin-logout')?.addEventListener('click', async ()=>{ await api('/api/logout', {method:'POST'}); location.reload(); });

async function loadAdmin(){ const pending = await api('/api/admin/pending'); const el = $('#admin-pending'); el.innerHTML=''; (pending.rows||[]).forEach(p=> el.innerHTML += `<div class="card"><b>${p.id}</b> ${p.name} ${p.email} ₦${p.amount}<br/><button onclick="approve('${p.id}')">Approve</button> <button onclick="reject('${p.id}')">Reject</button></div>`); const users = await api('/api/admin/users'); const ue = $('#admin-users'); ue.innerHTML=''; (users.rows||[]).forEach(u=> ue.innerHTML += `<div class="card">${u.email} • ₦${u.balance} • ${u.role}</div>`); }
window.approve = async (id)=>{ await api('/api/admin/approve',{method:'POST', body: JSON.stringify({id})}); loadAdmin(); alert('Approved'); }
window.reject = async (id)=>{ await api('/api/admin/reject',{method:'POST', body: JSON.stringify({id})}); loadAdmin(); alert('Rejected'); }

// boot
init();
