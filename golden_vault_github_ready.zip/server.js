
/*
Golden Vault Online - server.js
Minimal Express server with SQLite storage for demo purposes.
Auto-creates an admin user on first run: admin@golden.demo / admin123
*/
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data.db');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: '.' }),
  secret: process.env.SESSION_SECRET || 'change-me-please',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000*60*60*24 }
}));

const db = new sqlite3.Database(DB_FILE);
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, email TEXT UNIQUE, password TEXT, name TEXT, role TEXT, balance REAL DEFAULT 0,
    security_answer TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS deposits (
    id TEXT PRIMARY KEY, user_id TEXT, amount REAL, ref TEXT, ts INTEGER
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS withdrawals (
    id TEXT PRIMARY KEY, user_id TEXT, amount REAL, vat_code TEXT, otp TEXT, security_ok INTEGER DEFAULT 0,
    admin_approved INTEGER DEFAULT 0, status TEXT, ts INTEGER
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, from_user TEXT, to_user TEXT, body TEXT, ts INTEGER
  )`);
});

function requireAuth(req,res,next){
  if(req.session.userId) return next();
  res.status(401).json({error:'unauthenticated'});
}
function requireAdmin(req,res,next){
  if(req.session.userId && req.session.role==='admin') return next();
  res.status(403).json({error:'forbidden'});
}

// Boot admin if missing
db.get(`SELECT COUNT(*) as c FROM users WHERE role='admin'`, [], (e,r)=>{
  if(r && r.c===0){
    const id = uuidv4();
    bcrypt.hash('admin123',10).then(h=>{
      db.run(`INSERT INTO users(id,email,password,name,role,balance) VALUES(?,?,?,?,?,?)`, [id,'admin@golden.demo',h,'Admin','admin',0]);
      console.log('Admin created: admin@golden.demo / admin123');
    });
  }
});

// Auth
app.post('/api/register', async (req,res)=>{
  const { email, password, name, security_answer } = req.body;
  if(!email || !password) return res.status(400).json({error:'missing'});
  const id = uuidv4();
  const hashed = await bcrypt.hash(password, 10);
  db.run(`INSERT INTO users(id,email,password,name,role,security_answer) VALUES(?,?,?,?,?,?)`, [id,email,hashed,name||'Customer','user',(security_answer||'').toLowerCase()], function(err){
    if(err) return res.status(400).json({error:'email taken or db error', detail: err.message});
    req.session.userId = id; req.session.role = 'user';
    res.json({ok:true,id});
  });
});

app.post('/api/login', (req,res)=>{
  const { email, password } = req.body;
  db.get(`SELECT * FROM users WHERE email=?`, [email], async (err,row)=>{
    if(err || !row) return res.status(400).json({error:'invalid'});
    const match = await bcrypt.compare(password, row.password);
    if(!match) return res.status(400).json({error:'invalid'});
    req.session.userId = row.id; req.session.role = row.role;
    res.json({ok:true, id: row.id, role: row.role});
  });
});

app.post('/api/logout',(req,res)=>{ req.session.destroy(()=>res.json({ok:true})); });

// Me
app.get('/api/me',(req,res)=>{
  if(!req.session.userId) return res.json({user:null});
  db.get(`SELECT id,email,name,role,balance FROM users WHERE id=?`, [req.session.userId], (e,row)=> res.json({user: row||null}));
});

// Deposit
app.post('/api/deposit', requireAuth, (req,res)=>{
  const { amount, ref } = req.body;
  if(!amount || amount<=0) return res.status(400).json({error:'invalid amount'});
  const id = uuidv4(), ts = Date.now();
  db.run(`INSERT INTO deposits(id,user_id,amount,ref,ts) VALUES(?,?,?,?,?)`, [id,req.session.userId, amount, ref||'', ts], function(err){
    if(err) return res.status(500).json({error:'db'});
    db.run(`UPDATE users SET balance = balance + ? WHERE id = ?`, [amount, req.session.userId]);
    res.json({ok:true, id});
  });
});

// Withdraw start
app.post('/api/withdraw/start', requireAuth, (req,res)=>{
  const { amount, vat_code } = req.body;
  if(!amount || amount<=0) return res.status(400).json({error:'invalid amount'});
  db.get(`SELECT balance FROM users WHERE id=?`, [req.session.userId], (e,row)=>{
    if(!row || row.balance < amount) return res.status(400).json({error:'insufficient'});
    const id = uuidv4(); const otp = Math.floor(100000 + Math.random()*900000).toString(); const ts = Date.now();
    db.run(`INSERT INTO withdrawals(id,user_id,amount,vat_code,otp,status,ts) VALUES(?,?,?,?,?,?,?)`, [id,req.session.userId, amount, vat_code, otp, 'otp_sent', ts], function(err){
      if(err) return res.status(500).json({error:'db'});
      res.json({ok:true, id, otp});
    });
  });
});

// Verify OTP
app.post('/api/withdraw/verify-otp', requireAuth, (req,res)=>{
  const { id, otp } = req.body;
  db.get(`SELECT * FROM withdrawals WHERE id=? AND user_id=?`, [id, req.session.userId], (e,r)=>{
    if(!r) return res.status(400).json({error:'notfound'});
    if(r.otp !== otp) return res.status(400).json({error:'wrong'});
    db.run(`UPDATE withdrawals SET status='otp_verified' WHERE id=?`, [id], function(err){ res.json({ok:true}); });
  });
});

// Security answer step
app.post('/api/withdraw/security', requireAuth, (req,res)=>{
  const { id, answer } = req.body;
  if(!answer) return res.status(400).json({error:'missing'});
  db.get(`SELECT security_answer FROM users WHERE id=?`, [req.session.userId], (e,u)=>{
    if(!u) return res.status(400).json({error:'user'});
    if(u.security_answer !== answer.toLowerCase()) return res.status(400).json({error:'wrong'});
    db.run(`UPDATE withdrawals SET status='security_ok' WHERE id=?`, [id], function(err){ res.json({ok:true}); });
  });
});

// Check status
app.get('/api/withdraw/status/:id', requireAuth, (req,res)=>{
  const id = req.params.id;
  db.get(`SELECT * FROM withdrawals WHERE id=? AND user_id=?`, [id, req.session.userId], (e,r)=>{ if(!r) return res.status(404).json({error:'notfound'}); res.json({ok:true, request: r}); });
});

// Admin endpoints
app.get('/api/admin/pending', requireAdmin, (req,res)=>{
  db.all(`SELECT w.*, u.email, u.name FROM withdrawals w JOIN users u ON u.id = w.user_id WHERE w.admin_approved = 0 AND w.status IN ('security_ok','otp_verified','otp_sent')`, [], (e,rows)=> res.json({rows}));
});
app.post('/api/admin/approve', requireAdmin, (req,res)=>{
  const { id } = req.body;
  db.get(`SELECT * FROM withdrawals WHERE id=?`, [id], (e,r)=>{
    if(!r) return res.status(404).json({error:'notfound'});
    db.run(`UPDATE withdrawals SET admin_approved=1, status='approved' WHERE id=?`, [id], function(err){
      db.run(`UPDATE users SET balance = balance - ? WHERE id=?`, [r.amount, r.user_id]);
      res.json({ok:true});
    });
  });
});
app.post('/api/admin/reject', requireAdmin, (req,res)=>{
  const { id } = req.body;
  db.get(`SELECT * FROM withdrawals WHERE id=?`, [id], (e,r)=>{
    if(!r) return res.status(404).json({error:'notfound'});
    db.run(`UPDATE withdrawals SET admin_approved=0, status='rejected' WHERE id=?`, [id], function(err){ res.json({ok:true}); });
  });
});

// Messages simple
app.post('/api/admin/message', requireAdmin, (req,res)=>{
  const { to_user, body } = req.body; const id = uuidv4(), ts = Date.now();
  db.run(`INSERT INTO messages(id,from_user,to_user,body,ts) VALUES(?,?,?,?,?)`, [id, req.session.userId, to_user, body, ts], function(err){ res.json({ok:true}); });
});
app.get('/api/messages', requireAuth, (req,res)=>{
  db.all(`SELECT * FROM messages WHERE to_user = ? OR from_user = ? ORDER BY ts DESC`, [req.session.userId, req.session.userId], (e,rows)=> res.json({rows}));
});

// Users & transactions
app.get('/api/admin/users', requireAdmin, (req,res)=>{ db.all(`SELECT id,email,name,balance,role FROM users ORDER BY email`, [], (e,rows)=> res.json({rows})); });
app.get('/api/transactions', requireAuth, (req,res)=>{ db.all(`SELECT id,amount,ref,ts,'deposit' as type FROM deposits WHERE user_id=? UNION ALL SELECT id,amount,vat_code as ref,ts,'withdrawal' as type FROM withdrawals WHERE user_id=? ORDER BY ts DESC`, [req.session.userId, req.session.userId], (e,rows)=> res.json({rows})); });

app.listen(PORT, ()=> console.log('Server listening on port', PORT));
