
# Golden Vault Online Bank (GitHub-ready)

This repository contains the Golden Vault Online demo (server-backed).

## Quick deploy to Render
1. Create a new GitHub repository and upload these files (or push from your machine).
2. In Render, click **New → Web Service** and connect the repo (or click the Deploy button if available).
3. Build command: `npm install`
4. Start command: `npm start`
5. Set environment variable: `SESSION_SECRET` (recommended)

Or use Render's one-click deploy by adding this repo to your GitHub and using Render's deploy flow.

---

Default admin account (auto-created):
- email: `admin@golden.demo`
- password: `admin123`

Change credentials after first login.
